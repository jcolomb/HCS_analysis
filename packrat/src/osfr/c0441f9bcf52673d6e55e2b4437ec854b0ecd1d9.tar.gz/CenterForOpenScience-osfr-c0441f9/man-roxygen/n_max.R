#' @param n_max Maximum number of results to return from OSF (default is 10).
#'   Set to `Inf` to return *all* results.
