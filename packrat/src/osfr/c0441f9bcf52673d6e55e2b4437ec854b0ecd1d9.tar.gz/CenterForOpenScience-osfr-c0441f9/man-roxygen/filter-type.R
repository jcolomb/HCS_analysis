#' @param type Filter query by type. Set to `"file"` to list only files, or
#'   `"folder"`to list only folders
