#' @param pattern Character string used to filter for results that contain the
#'   substring `"pattern"` in their name. *Note:* this is a fixed, case-insensitive
#'   search.
