#' @param verbose Logical, indicating whether to print informative messages
#'   about interactions with the OSF API (default `FALSE`).
