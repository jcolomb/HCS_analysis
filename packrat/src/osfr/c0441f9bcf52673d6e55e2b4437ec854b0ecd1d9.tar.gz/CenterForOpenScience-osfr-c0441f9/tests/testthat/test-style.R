if (requireNamespace("lintr", quietly = TRUE)) {
  context("Code style")
  test_that("Code is lint free", {
    lintr::expect_lint_free()
  })
}
