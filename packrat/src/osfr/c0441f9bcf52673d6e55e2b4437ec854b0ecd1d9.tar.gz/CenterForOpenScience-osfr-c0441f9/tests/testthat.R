library(testthat)
library(osfr)

test_check("osfr")
