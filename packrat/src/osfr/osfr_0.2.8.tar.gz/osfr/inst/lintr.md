This file is here so that R CMD CHECK doesn't complain about an empty "inst" directory, but this directory must be there because we need the .lintr file so that codecov works.
