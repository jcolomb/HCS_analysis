.onLoad <- function(libname, pkgname) {
  library.dynam("audio", pkgname, libname)
}
