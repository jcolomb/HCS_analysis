#' A Server-Side File System Viewer for Shiny
"_PACKAGE"
